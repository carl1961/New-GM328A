﻿namespace avrdudess
{
    partial class FormFuseSelector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbLBits = new System.Windows.Forms.Label();
            this.lbLB7 = new System.Windows.Forms.Label();
            this.lbLB6 = new System.Windows.Forms.Label();
            this.lbLB5 = new System.Windows.Forms.Label();
            this.lbLB4 = new System.Windows.Forms.Label();
            this.lbLB3 = new System.Windows.Forms.Label();
            this.lbLB2 = new System.Windows.Forms.Label();
            this.lbLB1 = new System.Windows.Forms.Label();
            this.lbLB0 = new System.Windows.Forms.Label();
            this.cbLB7 = new System.Windows.Forms.CheckBox();
            this.cbLB6 = new System.Windows.Forms.CheckBox();
            this.cbLB5 = new System.Windows.Forms.CheckBox();
            this.cbLB4 = new System.Windows.Forms.CheckBox();
            this.cbLB3 = new System.Windows.Forms.CheckBox();
            this.cbLB2 = new System.Windows.Forms.CheckBox();
            this.cbLB1 = new System.Windows.Forms.CheckBox();
            this.cbLB0 = new System.Windows.Forms.CheckBox();
            this.grpFuses = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbEFuse = new System.Windows.Forms.Label();
            this.lbHFuse = new System.Windows.Forms.Label();
            this.lbLFuse = new System.Windows.Forms.Label();
            this.btnEF7 = new System.Windows.Forms.Button();
            this.btnEF6 = new System.Windows.Forms.Button();
            this.btnEF5 = new System.Windows.Forms.Button();
            this.btnEF4 = new System.Windows.Forms.Button();
            this.btnEF3 = new System.Windows.Forms.Button();
            this.btnEF2 = new System.Windows.Forms.Button();
            this.btnEF1 = new System.Windows.Forms.Button();
            this.btnEF0 = new System.Windows.Forms.Button();
            this.lbEFuse7 = new System.Windows.Forms.Label();
            this.lbEFuse6 = new System.Windows.Forms.Label();
            this.lbEFuse5 = new System.Windows.Forms.Label();
            this.lbEFuse4 = new System.Windows.Forms.Label();
            this.lbEFuse3 = new System.Windows.Forms.Label();
            this.lbEFuse2 = new System.Windows.Forms.Label();
            this.lbEFuse1 = new System.Windows.Forms.Label();
            this.lbEFuse0 = new System.Windows.Forms.Label();
            this.btnLFuse7 = new System.Windows.Forms.Button();
            this.btnLFuse6 = new System.Windows.Forms.Button();
            this.btnLF5 = new System.Windows.Forms.Button();
            this.btnLF4 = new System.Windows.Forms.Button();
            this.btnLF3 = new System.Windows.Forms.Button();
            this.btnLF2 = new System.Windows.Forms.Button();
            this.btnLF1 = new System.Windows.Forms.Button();
            this.btnLF0 = new System.Windows.Forms.Button();
            this.lbLFuse7 = new System.Windows.Forms.Label();
            this.lbLFuse6 = new System.Windows.Forms.Label();
            this.lbLFuse5 = new System.Windows.Forms.Label();
            this.lbLFuse4 = new System.Windows.Forms.Label();
            this.lbLFuse3 = new System.Windows.Forms.Label();
            this.lbLFuse2 = new System.Windows.Forms.Label();
            this.lbLFuse1 = new System.Windows.Forms.Label();
            this.lbLFuse0 = new System.Windows.Forms.Label();
            this.btnHF7 = new System.Windows.Forms.Button();
            this.btnHF6 = new System.Windows.Forms.Button();
            this.btnHF5 = new System.Windows.Forms.Button();
            this.btnHF4 = new System.Windows.Forms.Button();
            this.btnHF3 = new System.Windows.Forms.Button();
            this.btnHF2 = new System.Windows.Forms.Button();
            this.btnHF1 = new System.Windows.Forms.Button();
            this.btnHF0 = new System.Windows.Forms.Button();
            this.lbHFuse7 = new System.Windows.Forms.Label();
            this.lbHFuse6 = new System.Windows.Forms.Label();
            this.lbHFuse5 = new System.Windows.Forms.Label();
            this.lbHFuse4 = new System.Windows.Forms.Label();
            this.lbHFuse3 = new System.Windows.Forms.Label();
            this.lbHFuse2 = new System.Windows.Forms.Label();
            this.lbHFuse1 = new System.Windows.Forms.Label();
            this.lbHFuse0 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblCarefulNow = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.grpFuses.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lbLBits);
            this.groupBox1.Controls.Add(this.lbLB7);
            this.groupBox1.Controls.Add(this.lbLB6);
            this.groupBox1.Controls.Add(this.lbLB5);
            this.groupBox1.Controls.Add(this.lbLB4);
            this.groupBox1.Controls.Add(this.lbLB3);
            this.groupBox1.Controls.Add(this.lbLB2);
            this.groupBox1.Controls.Add(this.lbLB1);
            this.groupBox1.Controls.Add(this.lbLB0);
            this.groupBox1.Controls.Add(this.cbLB7);
            this.groupBox1.Controls.Add(this.cbLB6);
            this.groupBox1.Controls.Add(this.cbLB5);
            this.groupBox1.Controls.Add(this.cbLB4);
            this.groupBox1.Controls.Add(this.cbLB3);
            this.groupBox1.Controls.Add(this.cbLB2);
            this.groupBox1.Controls.Add(this.cbLB1);
            this.groupBox1.Controls.Add(this.cbLB0);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(732, 69);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "_GRP_LOCKBITS";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(642, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(79, 15);
            this.label4.TabIndex = 84;
            this.label4.Text = "_LOCKBITS";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLBits
            // 
            this.lbLBits.Location = new System.Drawing.Point(642, 47);
            this.lbLBits.Name = "lbLBits";
            this.lbLBits.Size = new System.Drawing.Size(79, 13);
            this.lbLBits.TabIndex = 81;
            this.lbLBits.Text = "lbLBits";
            this.lbLBits.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbLB7
            // 
            this.lbLB7.Location = new System.Drawing.Point(3, 24);
            this.lbLB7.Name = "lbLB7";
            this.lbLB7.Size = new System.Drawing.Size(79, 15);
            this.lbLB7.TabIndex = 15;
            this.lbLB7.Text = "lbLockBits";
            this.lbLB7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLB6
            // 
            this.lbLB6.Location = new System.Drawing.Point(82, 24);
            this.lbLB6.Name = "lbLB6";
            this.lbLB6.Size = new System.Drawing.Size(79, 15);
            this.lbLB6.TabIndex = 14;
            this.lbLB6.Text = "lbLockBits";
            this.lbLB6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLB5
            // 
            this.lbLB5.Location = new System.Drawing.Point(161, 24);
            this.lbLB5.Name = "lbLB5";
            this.lbLB5.Size = new System.Drawing.Size(79, 15);
            this.lbLB5.TabIndex = 13;
            this.lbLB5.Text = "lbLockBits";
            this.lbLB5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLB4
            // 
            this.lbLB4.Location = new System.Drawing.Point(240, 24);
            this.lbLB4.Name = "lbLB4";
            this.lbLB4.Size = new System.Drawing.Size(79, 15);
            this.lbLB4.TabIndex = 12;
            this.lbLB4.Text = "lbLockBits";
            this.lbLB4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLB3
            // 
            this.lbLB3.Location = new System.Drawing.Point(319, 24);
            this.lbLB3.Name = "lbLB3";
            this.lbLB3.Size = new System.Drawing.Size(79, 15);
            this.lbLB3.TabIndex = 11;
            this.lbLB3.Text = "lbLockBits";
            this.lbLB3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLB2
            // 
            this.lbLB2.Location = new System.Drawing.Point(398, 24);
            this.lbLB2.Name = "lbLB2";
            this.lbLB2.Size = new System.Drawing.Size(79, 15);
            this.lbLB2.TabIndex = 10;
            this.lbLB2.Text = "lbLockBits";
            this.lbLB2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLB1
            // 
            this.lbLB1.Location = new System.Drawing.Point(477, 24);
            this.lbLB1.Name = "lbLB1";
            this.lbLB1.Size = new System.Drawing.Size(79, 15);
            this.lbLB1.TabIndex = 9;
            this.lbLB1.Text = "lbLockBits";
            this.lbLB1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLB0
            // 
            this.lbLB0.Location = new System.Drawing.Point(556, 24);
            this.lbLB0.Name = "lbLB0";
            this.lbLB0.Size = new System.Drawing.Size(79, 15);
            this.lbLB0.TabIndex = 8;
            this.lbLB0.Text = "lbLockBits";
            this.lbLB0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbLB7
            // 
            this.cbLB7.AutoSize = true;
            this.cbLB7.Location = new System.Drawing.Point(37, 47);
            this.cbLB7.Name = "cbLB7";
            this.cbLB7.Size = new System.Drawing.Size(15, 14);
            this.cbLB7.TabIndex = 7;
            this.cbLB7.UseVisualStyleBackColor = true;
            // 
            // cbLB6
            // 
            this.cbLB6.AutoSize = true;
            this.cbLB6.Location = new System.Drawing.Point(116, 47);
            this.cbLB6.Name = "cbLB6";
            this.cbLB6.Size = new System.Drawing.Size(15, 14);
            this.cbLB6.TabIndex = 6;
            this.cbLB6.UseVisualStyleBackColor = true;
            // 
            // cbLB5
            // 
            this.cbLB5.AutoSize = true;
            this.cbLB5.Location = new System.Drawing.Point(195, 47);
            this.cbLB5.Name = "cbLB5";
            this.cbLB5.Size = new System.Drawing.Size(15, 14);
            this.cbLB5.TabIndex = 5;
            this.cbLB5.UseVisualStyleBackColor = true;
            // 
            // cbLB4
            // 
            this.cbLB4.AutoSize = true;
            this.cbLB4.Location = new System.Drawing.Point(274, 47);
            this.cbLB4.Name = "cbLB4";
            this.cbLB4.Size = new System.Drawing.Size(15, 14);
            this.cbLB4.TabIndex = 4;
            this.cbLB4.UseVisualStyleBackColor = true;
            // 
            // cbLB3
            // 
            this.cbLB3.AutoSize = true;
            this.cbLB3.Location = new System.Drawing.Point(353, 47);
            this.cbLB3.Name = "cbLB3";
            this.cbLB3.Size = new System.Drawing.Size(15, 14);
            this.cbLB3.TabIndex = 3;
            this.cbLB3.UseVisualStyleBackColor = true;
            // 
            // cbLB2
            // 
            this.cbLB2.AutoSize = true;
            this.cbLB2.Location = new System.Drawing.Point(432, 47);
            this.cbLB2.Name = "cbLB2";
            this.cbLB2.Size = new System.Drawing.Size(15, 14);
            this.cbLB2.TabIndex = 2;
            this.cbLB2.UseVisualStyleBackColor = true;
            // 
            // cbLB1
            // 
            this.cbLB1.AutoSize = true;
            this.cbLB1.Location = new System.Drawing.Point(511, 47);
            this.cbLB1.Name = "cbLB1";
            this.cbLB1.Size = new System.Drawing.Size(15, 14);
            this.cbLB1.TabIndex = 1;
            this.cbLB1.UseVisualStyleBackColor = true;
            // 
            // cbLB0
            // 
            this.cbLB0.AutoSize = true;
            this.cbLB0.Location = new System.Drawing.Point(590, 47);
            this.cbLB0.Name = "cbLB0";
            this.cbLB0.Size = new System.Drawing.Size(15, 14);
            this.cbLB0.TabIndex = 0;
            this.cbLB0.UseVisualStyleBackColor = true;
            // 
            // grpFuses
            // 
            this.grpFuses.Controls.Add(this.label3);
            this.grpFuses.Controls.Add(this.label2);
            this.grpFuses.Controls.Add(this.label1);
            this.grpFuses.Controls.Add(this.lbEFuse);
            this.grpFuses.Controls.Add(this.lbHFuse);
            this.grpFuses.Controls.Add(this.lbLFuse);
            this.grpFuses.Controls.Add(this.btnEF7);
            this.grpFuses.Controls.Add(this.btnEF6);
            this.grpFuses.Controls.Add(this.btnEF5);
            this.grpFuses.Controls.Add(this.btnEF4);
            this.grpFuses.Controls.Add(this.btnEF3);
            this.grpFuses.Controls.Add(this.btnEF2);
            this.grpFuses.Controls.Add(this.btnEF1);
            this.grpFuses.Controls.Add(this.btnEF0);
            this.grpFuses.Controls.Add(this.lbEFuse7);
            this.grpFuses.Controls.Add(this.lbEFuse6);
            this.grpFuses.Controls.Add(this.lbEFuse5);
            this.grpFuses.Controls.Add(this.lbEFuse4);
            this.grpFuses.Controls.Add(this.lbEFuse3);
            this.grpFuses.Controls.Add(this.lbEFuse2);
            this.grpFuses.Controls.Add(this.lbEFuse1);
            this.grpFuses.Controls.Add(this.lbEFuse0);
            this.grpFuses.Controls.Add(this.btnLFuse7);
            this.grpFuses.Controls.Add(this.btnLFuse6);
            this.grpFuses.Controls.Add(this.btnLF5);
            this.grpFuses.Controls.Add(this.btnLF4);
            this.grpFuses.Controls.Add(this.btnLF3);
            this.grpFuses.Controls.Add(this.btnLF2);
            this.grpFuses.Controls.Add(this.btnLF1);
            this.grpFuses.Controls.Add(this.btnLF0);
            this.grpFuses.Controls.Add(this.lbLFuse7);
            this.grpFuses.Controls.Add(this.lbLFuse6);
            this.grpFuses.Controls.Add(this.lbLFuse5);
            this.grpFuses.Controls.Add(this.lbLFuse4);
            this.grpFuses.Controls.Add(this.lbLFuse3);
            this.grpFuses.Controls.Add(this.lbLFuse2);
            this.grpFuses.Controls.Add(this.lbLFuse1);
            this.grpFuses.Controls.Add(this.lbLFuse0);
            this.grpFuses.Controls.Add(this.btnHF7);
            this.grpFuses.Controls.Add(this.btnHF6);
            this.grpFuses.Controls.Add(this.btnHF5);
            this.grpFuses.Controls.Add(this.btnHF4);
            this.grpFuses.Controls.Add(this.btnHF3);
            this.grpFuses.Controls.Add(this.btnHF2);
            this.grpFuses.Controls.Add(this.btnHF1);
            this.grpFuses.Controls.Add(this.btnHF0);
            this.grpFuses.Controls.Add(this.lbHFuse7);
            this.grpFuses.Controls.Add(this.lbHFuse6);
            this.grpFuses.Controls.Add(this.lbHFuse5);
            this.grpFuses.Controls.Add(this.lbHFuse4);
            this.grpFuses.Controls.Add(this.lbHFuse3);
            this.grpFuses.Controls.Add(this.lbHFuse2);
            this.grpFuses.Controls.Add(this.lbHFuse1);
            this.grpFuses.Controls.Add(this.lbHFuse0);
            this.grpFuses.Location = new System.Drawing.Point(12, 87);
            this.grpFuses.Name = "grpFuses";
            this.grpFuses.Size = new System.Drawing.Size(732, 180);
            this.grpFuses.TabIndex = 1;
            this.grpFuses.TabStop = false;
            this.grpFuses.Text = "_GRP_FUSEBITS";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(642, 130);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 15);
            this.label3.TabIndex = 85;
            this.label3.Text = "EFUSE";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(642, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 15);
            this.label2.TabIndex = 84;
            this.label2.Text = "HFUSE";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(642, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 83;
            this.label1.Text = "LFUSE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEFuse
            // 
            this.lbEFuse.Location = new System.Drawing.Point(642, 152);
            this.lbEFuse.Name = "lbEFuse";
            this.lbEFuse.Size = new System.Drawing.Size(79, 13);
            this.lbEFuse.TabIndex = 82;
            this.lbEFuse.Text = "lbEFuse";
            this.lbEFuse.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbHFuse
            // 
            this.lbHFuse.Location = new System.Drawing.Point(642, 99);
            this.lbHFuse.Name = "lbHFuse";
            this.lbHFuse.Size = new System.Drawing.Size(79, 13);
            this.lbHFuse.TabIndex = 81;
            this.lbHFuse.Text = "lbHFuse";
            this.lbHFuse.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbLFuse
            // 
            this.lbLFuse.Location = new System.Drawing.Point(642, 45);
            this.lbLFuse.Name = "lbLFuse";
            this.lbLFuse.Size = new System.Drawing.Size(79, 13);
            this.lbLFuse.TabIndex = 80;
            this.lbLFuse.Text = "lbLFuse";
            this.lbLFuse.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnEF7
            // 
            this.btnEF7.Location = new System.Drawing.Point(32, 148);
            this.btnEF7.Name = "btnEF7";
            this.btnEF7.Size = new System.Drawing.Size(25, 21);
            this.btnEF7.TabIndex = 79;
            this.btnEF7.Text = "btnHFuse";
            this.btnEF7.UseVisualStyleBackColor = true;
            // 
            // btnEF6
            // 
            this.btnEF6.Location = new System.Drawing.Point(111, 148);
            this.btnEF6.Name = "btnEF6";
            this.btnEF6.Size = new System.Drawing.Size(25, 21);
            this.btnEF6.TabIndex = 78;
            this.btnEF6.Text = "btnHFuse";
            this.btnEF6.UseVisualStyleBackColor = true;
            // 
            // btnEF5
            // 
            this.btnEF5.Location = new System.Drawing.Point(190, 148);
            this.btnEF5.Name = "btnEF5";
            this.btnEF5.Size = new System.Drawing.Size(25, 21);
            this.btnEF5.TabIndex = 77;
            this.btnEF5.Text = "btnHFuse";
            this.btnEF5.UseVisualStyleBackColor = true;
            // 
            // btnEF4
            // 
            this.btnEF4.Location = new System.Drawing.Point(269, 148);
            this.btnEF4.Name = "btnEF4";
            this.btnEF4.Size = new System.Drawing.Size(25, 21);
            this.btnEF4.TabIndex = 76;
            this.btnEF4.Text = "btnHFuse";
            this.btnEF4.UseVisualStyleBackColor = true;
            // 
            // btnEF3
            // 
            this.btnEF3.Location = new System.Drawing.Point(348, 148);
            this.btnEF3.Name = "btnEF3";
            this.btnEF3.Size = new System.Drawing.Size(25, 21);
            this.btnEF3.TabIndex = 75;
            this.btnEF3.Text = "btnHFuse";
            this.btnEF3.UseVisualStyleBackColor = true;
            // 
            // btnEF2
            // 
            this.btnEF2.Location = new System.Drawing.Point(427, 148);
            this.btnEF2.Name = "btnEF2";
            this.btnEF2.Size = new System.Drawing.Size(25, 21);
            this.btnEF2.TabIndex = 74;
            this.btnEF2.Text = "btnHFuse";
            this.btnEF2.UseVisualStyleBackColor = true;
            // 
            // btnEF1
            // 
            this.btnEF1.Location = new System.Drawing.Point(506, 148);
            this.btnEF1.Name = "btnEF1";
            this.btnEF1.Size = new System.Drawing.Size(25, 21);
            this.btnEF1.TabIndex = 73;
            this.btnEF1.Text = "btnHFuse";
            this.btnEF1.UseVisualStyleBackColor = true;
            // 
            // btnEF0
            // 
            this.btnEF0.Location = new System.Drawing.Point(585, 148);
            this.btnEF0.Name = "btnEF0";
            this.btnEF0.Size = new System.Drawing.Size(25, 21);
            this.btnEF0.TabIndex = 72;
            this.btnEF0.Text = "btnHFuse";
            this.btnEF0.UseVisualStyleBackColor = true;
            // 
            // lbEFuse7
            // 
            this.lbEFuse7.Location = new System.Drawing.Point(4, 130);
            this.lbEFuse7.Name = "lbEFuse7";
            this.lbEFuse7.Size = new System.Drawing.Size(79, 15);
            this.lbEFuse7.TabIndex = 71;
            this.lbEFuse7.Text = "lbEFuse";
            this.lbEFuse7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEFuse6
            // 
            this.lbEFuse6.Location = new System.Drawing.Point(83, 130);
            this.lbEFuse6.Name = "lbEFuse6";
            this.lbEFuse6.Size = new System.Drawing.Size(79, 15);
            this.lbEFuse6.TabIndex = 70;
            this.lbEFuse6.Text = "lbEFuse";
            this.lbEFuse6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEFuse5
            // 
            this.lbEFuse5.Location = new System.Drawing.Point(162, 130);
            this.lbEFuse5.Name = "lbEFuse5";
            this.lbEFuse5.Size = new System.Drawing.Size(79, 15);
            this.lbEFuse5.TabIndex = 69;
            this.lbEFuse5.Text = "lbEFuse";
            this.lbEFuse5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEFuse4
            // 
            this.lbEFuse4.Location = new System.Drawing.Point(241, 130);
            this.lbEFuse4.Name = "lbEFuse4";
            this.lbEFuse4.Size = new System.Drawing.Size(79, 15);
            this.lbEFuse4.TabIndex = 68;
            this.lbEFuse4.Text = "lbEFuse";
            this.lbEFuse4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEFuse3
            // 
            this.lbEFuse3.Location = new System.Drawing.Point(320, 130);
            this.lbEFuse3.Name = "lbEFuse3";
            this.lbEFuse3.Size = new System.Drawing.Size(79, 15);
            this.lbEFuse3.TabIndex = 67;
            this.lbEFuse3.Text = "lbEFuse";
            this.lbEFuse3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEFuse2
            // 
            this.lbEFuse2.Location = new System.Drawing.Point(399, 130);
            this.lbEFuse2.Name = "lbEFuse2";
            this.lbEFuse2.Size = new System.Drawing.Size(79, 15);
            this.lbEFuse2.TabIndex = 66;
            this.lbEFuse2.Text = "lbEFuse";
            this.lbEFuse2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEFuse1
            // 
            this.lbEFuse1.Location = new System.Drawing.Point(478, 130);
            this.lbEFuse1.Name = "lbEFuse1";
            this.lbEFuse1.Size = new System.Drawing.Size(79, 15);
            this.lbEFuse1.TabIndex = 65;
            this.lbEFuse1.Text = "lbEFuse";
            this.lbEFuse1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbEFuse0
            // 
            this.lbEFuse0.Location = new System.Drawing.Point(557, 130);
            this.lbEFuse0.Name = "lbEFuse0";
            this.lbEFuse0.Size = new System.Drawing.Size(79, 15);
            this.lbEFuse0.TabIndex = 64;
            this.lbEFuse0.Text = "lbEFuse";
            this.lbEFuse0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnLFuse7
            // 
            this.btnLFuse7.Location = new System.Drawing.Point(32, 41);
            this.btnLFuse7.Name = "btnLFuse7";
            this.btnLFuse7.Size = new System.Drawing.Size(25, 21);
            this.btnLFuse7.TabIndex = 63;
            this.btnLFuse7.Text = "btnHFuse";
            this.btnLFuse7.UseVisualStyleBackColor = true;
            // 
            // btnLFuse6
            // 
            this.btnLFuse6.Location = new System.Drawing.Point(111, 41);
            this.btnLFuse6.Name = "btnLFuse6";
            this.btnLFuse6.Size = new System.Drawing.Size(25, 21);
            this.btnLFuse6.TabIndex = 62;
            this.btnLFuse6.Text = "btnHFuse";
            this.btnLFuse6.UseVisualStyleBackColor = true;
            // 
            // btnLF5
            // 
            this.btnLF5.Location = new System.Drawing.Point(190, 41);
            this.btnLF5.Name = "btnLF5";
            this.btnLF5.Size = new System.Drawing.Size(25, 21);
            this.btnLF5.TabIndex = 61;
            this.btnLF5.Text = "btnHFuse";
            this.btnLF5.UseVisualStyleBackColor = true;
            // 
            // btnLF4
            // 
            this.btnLF4.Location = new System.Drawing.Point(269, 41);
            this.btnLF4.Name = "btnLF4";
            this.btnLF4.Size = new System.Drawing.Size(25, 21);
            this.btnLF4.TabIndex = 60;
            this.btnLF4.Text = "btnHFuse";
            this.btnLF4.UseVisualStyleBackColor = true;
            // 
            // btnLF3
            // 
            this.btnLF3.Location = new System.Drawing.Point(348, 41);
            this.btnLF3.Name = "btnLF3";
            this.btnLF3.Size = new System.Drawing.Size(25, 21);
            this.btnLF3.TabIndex = 59;
            this.btnLF3.Text = "btnHFuse";
            this.btnLF3.UseVisualStyleBackColor = true;
            // 
            // btnLF2
            // 
            this.btnLF2.Location = new System.Drawing.Point(427, 41);
            this.btnLF2.Name = "btnLF2";
            this.btnLF2.Size = new System.Drawing.Size(25, 21);
            this.btnLF2.TabIndex = 58;
            this.btnLF2.Text = "btnHFuse";
            this.btnLF2.UseVisualStyleBackColor = true;
            // 
            // btnLF1
            // 
            this.btnLF1.Location = new System.Drawing.Point(506, 41);
            this.btnLF1.Name = "btnLF1";
            this.btnLF1.Size = new System.Drawing.Size(25, 21);
            this.btnLF1.TabIndex = 57;
            this.btnLF1.Text = "btnHFuse";
            this.btnLF1.UseVisualStyleBackColor = true;
            // 
            // btnLF0
            // 
            this.btnLF0.Location = new System.Drawing.Point(585, 41);
            this.btnLF0.Name = "btnLF0";
            this.btnLF0.Size = new System.Drawing.Size(25, 21);
            this.btnLF0.TabIndex = 56;
            this.btnLF0.Text = "btnHFuse";
            this.btnLF0.UseVisualStyleBackColor = true;
            // 
            // lbLFuse7
            // 
            this.lbLFuse7.Location = new System.Drawing.Point(4, 23);
            this.lbLFuse7.Name = "lbLFuse7";
            this.lbLFuse7.Size = new System.Drawing.Size(79, 15);
            this.lbLFuse7.TabIndex = 55;
            this.lbLFuse7.Text = "lbLFuse";
            this.lbLFuse7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLFuse6
            // 
            this.lbLFuse6.Location = new System.Drawing.Point(83, 23);
            this.lbLFuse6.Name = "lbLFuse6";
            this.lbLFuse6.Size = new System.Drawing.Size(79, 15);
            this.lbLFuse6.TabIndex = 54;
            this.lbLFuse6.Text = "lbLFuse";
            this.lbLFuse6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLFuse5
            // 
            this.lbLFuse5.Location = new System.Drawing.Point(162, 23);
            this.lbLFuse5.Name = "lbLFuse5";
            this.lbLFuse5.Size = new System.Drawing.Size(79, 15);
            this.lbLFuse5.TabIndex = 53;
            this.lbLFuse5.Text = "lbLFuse";
            this.lbLFuse5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLFuse4
            // 
            this.lbLFuse4.Location = new System.Drawing.Point(241, 23);
            this.lbLFuse4.Name = "lbLFuse4";
            this.lbLFuse4.Size = new System.Drawing.Size(79, 15);
            this.lbLFuse4.TabIndex = 52;
            this.lbLFuse4.Text = "lbLFuse";
            this.lbLFuse4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLFuse3
            // 
            this.lbLFuse3.Location = new System.Drawing.Point(320, 23);
            this.lbLFuse3.Name = "lbLFuse3";
            this.lbLFuse3.Size = new System.Drawing.Size(79, 15);
            this.lbLFuse3.TabIndex = 51;
            this.lbLFuse3.Text = "lbLFuse";
            this.lbLFuse3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLFuse2
            // 
            this.lbLFuse2.Location = new System.Drawing.Point(399, 23);
            this.lbLFuse2.Name = "lbLFuse2";
            this.lbLFuse2.Size = new System.Drawing.Size(79, 15);
            this.lbLFuse2.TabIndex = 50;
            this.lbLFuse2.Text = "lbLFuse";
            this.lbLFuse2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLFuse1
            // 
            this.lbLFuse1.Location = new System.Drawing.Point(478, 23);
            this.lbLFuse1.Name = "lbLFuse1";
            this.lbLFuse1.Size = new System.Drawing.Size(79, 15);
            this.lbLFuse1.TabIndex = 49;
            this.lbLFuse1.Text = "lbLFuse";
            this.lbLFuse1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbLFuse0
            // 
            this.lbLFuse0.Location = new System.Drawing.Point(557, 23);
            this.lbLFuse0.Name = "lbLFuse0";
            this.lbLFuse0.Size = new System.Drawing.Size(79, 15);
            this.lbLFuse0.TabIndex = 48;
            this.lbLFuse0.Text = "lbLFuse";
            this.lbLFuse0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnHF7
            // 
            this.btnHF7.Location = new System.Drawing.Point(32, 95);
            this.btnHF7.Name = "btnHF7";
            this.btnHF7.Size = new System.Drawing.Size(25, 21);
            this.btnHF7.TabIndex = 47;
            this.btnHF7.Text = "btnHFuse";
            this.btnHF7.UseVisualStyleBackColor = true;
            // 
            // btnHF6
            // 
            this.btnHF6.Location = new System.Drawing.Point(111, 95);
            this.btnHF6.Name = "btnHF6";
            this.btnHF6.Size = new System.Drawing.Size(25, 21);
            this.btnHF6.TabIndex = 46;
            this.btnHF6.Text = "btnHFuse";
            this.btnHF6.UseVisualStyleBackColor = true;
            // 
            // btnHF5
            // 
            this.btnHF5.Location = new System.Drawing.Point(190, 95);
            this.btnHF5.Name = "btnHF5";
            this.btnHF5.Size = new System.Drawing.Size(25, 21);
            this.btnHF5.TabIndex = 45;
            this.btnHF5.Text = "btnHFuse";
            this.btnHF5.UseVisualStyleBackColor = true;
            // 
            // btnHF4
            // 
            this.btnHF4.Location = new System.Drawing.Point(269, 95);
            this.btnHF4.Name = "btnHF4";
            this.btnHF4.Size = new System.Drawing.Size(25, 21);
            this.btnHF4.TabIndex = 44;
            this.btnHF4.Text = "btnHFuse";
            this.btnHF4.UseVisualStyleBackColor = true;
            // 
            // btnHF3
            // 
            this.btnHF3.Location = new System.Drawing.Point(348, 95);
            this.btnHF3.Name = "btnHF3";
            this.btnHF3.Size = new System.Drawing.Size(25, 21);
            this.btnHF3.TabIndex = 43;
            this.btnHF3.Text = "btnHFuse";
            this.btnHF3.UseVisualStyleBackColor = true;
            // 
            // btnHF2
            // 
            this.btnHF2.Location = new System.Drawing.Point(427, 95);
            this.btnHF2.Name = "btnHF2";
            this.btnHF2.Size = new System.Drawing.Size(25, 21);
            this.btnHF2.TabIndex = 42;
            this.btnHF2.Text = "btnHFuse";
            this.btnHF2.UseVisualStyleBackColor = true;
            // 
            // btnHF1
            // 
            this.btnHF1.Location = new System.Drawing.Point(506, 95);
            this.btnHF1.Name = "btnHF1";
            this.btnHF1.Size = new System.Drawing.Size(25, 21);
            this.btnHF1.TabIndex = 41;
            this.btnHF1.Text = "btnHFuse";
            this.btnHF1.UseVisualStyleBackColor = true;
            // 
            // btnHF0
            // 
            this.btnHF0.Location = new System.Drawing.Point(585, 95);
            this.btnHF0.Name = "btnHF0";
            this.btnHF0.Size = new System.Drawing.Size(25, 21);
            this.btnHF0.TabIndex = 40;
            this.btnHF0.Text = "btnHFuse";
            this.btnHF0.UseVisualStyleBackColor = true;
            // 
            // lbHFuse7
            // 
            this.lbHFuse7.Location = new System.Drawing.Point(4, 77);
            this.lbHFuse7.Name = "lbHFuse7";
            this.lbHFuse7.Size = new System.Drawing.Size(79, 15);
            this.lbHFuse7.TabIndex = 31;
            this.lbHFuse7.Text = "lbHFuse";
            this.lbHFuse7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbHFuse6
            // 
            this.lbHFuse6.Location = new System.Drawing.Point(83, 77);
            this.lbHFuse6.Name = "lbHFuse6";
            this.lbHFuse6.Size = new System.Drawing.Size(79, 15);
            this.lbHFuse6.TabIndex = 30;
            this.lbHFuse6.Text = "lbHFuse";
            this.lbHFuse6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbHFuse5
            // 
            this.lbHFuse5.Location = new System.Drawing.Point(162, 77);
            this.lbHFuse5.Name = "lbHFuse5";
            this.lbHFuse5.Size = new System.Drawing.Size(79, 15);
            this.lbHFuse5.TabIndex = 29;
            this.lbHFuse5.Text = "lbHFuse";
            this.lbHFuse5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbHFuse4
            // 
            this.lbHFuse4.Location = new System.Drawing.Point(241, 77);
            this.lbHFuse4.Name = "lbHFuse4";
            this.lbHFuse4.Size = new System.Drawing.Size(79, 15);
            this.lbHFuse4.TabIndex = 28;
            this.lbHFuse4.Text = "lbHFuse";
            this.lbHFuse4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbHFuse3
            // 
            this.lbHFuse3.Location = new System.Drawing.Point(320, 77);
            this.lbHFuse3.Name = "lbHFuse3";
            this.lbHFuse3.Size = new System.Drawing.Size(79, 15);
            this.lbHFuse3.TabIndex = 27;
            this.lbHFuse3.Text = "lbHFuse";
            this.lbHFuse3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbHFuse2
            // 
            this.lbHFuse2.Location = new System.Drawing.Point(399, 77);
            this.lbHFuse2.Name = "lbHFuse2";
            this.lbHFuse2.Size = new System.Drawing.Size(79, 15);
            this.lbHFuse2.TabIndex = 26;
            this.lbHFuse2.Text = "lbHFuse";
            this.lbHFuse2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbHFuse1
            // 
            this.lbHFuse1.Location = new System.Drawing.Point(478, 77);
            this.lbHFuse1.Name = "lbHFuse1";
            this.lbHFuse1.Size = new System.Drawing.Size(79, 15);
            this.lbHFuse1.TabIndex = 25;
            this.lbHFuse1.Text = "lbHFuse";
            this.lbHFuse1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbHFuse0
            // 
            this.lbHFuse0.Location = new System.Drawing.Point(557, 77);
            this.lbHFuse0.Name = "lbHFuse0";
            this.lbHFuse0.Size = new System.Drawing.Size(79, 15);
            this.lbHFuse0.TabIndex = 24;
            this.lbHFuse0.Text = "lbHFuse";
            this.lbHFuse0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(570, 273);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(84, 25);
            this.btnOK.TabIndex = 2;
            this.btnOK.Text = "_OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(660, 273);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 25);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "_CANCEL";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // lblCarefulNow
            // 
            this.lblCarefulNow.AutoSize = true;
            this.lblCarefulNow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCarefulNow.ForeColor = System.Drawing.Color.Red;
            this.lblCarefulNow.Location = new System.Drawing.Point(12, 274);
            this.lblCarefulNow.Name = "lblCarefulNow";
            this.lblCarefulNow.Size = new System.Drawing.Size(130, 20);
            this.lblCarefulNow.TabIndex = 4;
            this.lblCarefulNow.Text = "_UNSUPPMCU";
            // 
            // FormFuseSelector
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(758, 306);
            this.Controls.Add(this.lblCarefulNow);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.grpFuses);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormFuseSelector";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Fuse & lock bits :";
            this.Load += new System.EventHandler(this.FormFusesAndLocks_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpFuses.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cbLB0;
        private System.Windows.Forms.CheckBox cbLB7;
        private System.Windows.Forms.CheckBox cbLB6;
        private System.Windows.Forms.CheckBox cbLB5;
        private System.Windows.Forms.CheckBox cbLB4;
        private System.Windows.Forms.CheckBox cbLB3;
        private System.Windows.Forms.CheckBox cbLB2;
        private System.Windows.Forms.CheckBox cbLB1;
        private System.Windows.Forms.Label lbLB0;
        private System.Windows.Forms.Label lbLB7;
        private System.Windows.Forms.Label lbLB6;
        private System.Windows.Forms.Label lbLB5;
        private System.Windows.Forms.Label lbLB4;
        private System.Windows.Forms.Label lbLB3;
        private System.Windows.Forms.Label lbLB2;
        private System.Windows.Forms.Label lbLB1;
        private System.Windows.Forms.GroupBox grpFuses;
        private System.Windows.Forms.Button btnHF7;
        private System.Windows.Forms.Button btnHF6;
        private System.Windows.Forms.Button btnHF5;
        private System.Windows.Forms.Button btnHF4;
        private System.Windows.Forms.Button btnHF3;
        private System.Windows.Forms.Button btnHF2;
        private System.Windows.Forms.Button btnHF1;
        private System.Windows.Forms.Button btnHF0;
        private System.Windows.Forms.Label lbHFuse7;
        private System.Windows.Forms.Label lbHFuse6;
        private System.Windows.Forms.Label lbHFuse5;
        private System.Windows.Forms.Label lbHFuse4;
        private System.Windows.Forms.Label lbHFuse3;
        private System.Windows.Forms.Label lbHFuse2;
        private System.Windows.Forms.Label lbHFuse1;
        private System.Windows.Forms.Label lbHFuse0;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnEF7;
        private System.Windows.Forms.Button btnEF6;
        private System.Windows.Forms.Button btnEF5;
        private System.Windows.Forms.Button btnEF4;
        private System.Windows.Forms.Button btnEF3;
        private System.Windows.Forms.Button btnEF2;
        private System.Windows.Forms.Button btnEF1;
        private System.Windows.Forms.Button btnEF0;
        private System.Windows.Forms.Label lbEFuse7;
        private System.Windows.Forms.Label lbEFuse6;
        private System.Windows.Forms.Label lbEFuse5;
        private System.Windows.Forms.Label lbEFuse4;
        private System.Windows.Forms.Label lbEFuse3;
        private System.Windows.Forms.Label lbEFuse2;
        private System.Windows.Forms.Label lbEFuse1;
        private System.Windows.Forms.Label lbEFuse0;
        private System.Windows.Forms.Button btnLFuse7;
        private System.Windows.Forms.Button btnLFuse6;
        private System.Windows.Forms.Button btnLF5;
        private System.Windows.Forms.Button btnLF4;
        private System.Windows.Forms.Button btnLF3;
        private System.Windows.Forms.Button btnLF2;
        private System.Windows.Forms.Button btnLF1;
        private System.Windows.Forms.Button btnLF0;
        private System.Windows.Forms.Label lbLFuse7;
        private System.Windows.Forms.Label lbLFuse6;
        private System.Windows.Forms.Label lbLFuse5;
        private System.Windows.Forms.Label lbLFuse4;
        private System.Windows.Forms.Label lbLFuse3;
        private System.Windows.Forms.Label lbLFuse2;
        private System.Windows.Forms.Label lbLFuse1;
        private System.Windows.Forms.Label lbLFuse0;
        private System.Windows.Forms.Label lbLFuse;
        private System.Windows.Forms.Label lbLBits;
        private System.Windows.Forms.Label lbEFuse;
        private System.Windows.Forms.Label lbHFuse;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblCarefulNow;
    }
}